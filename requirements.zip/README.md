# django-blog
django blog project for UW python course
